package com.example.APIBancarioJ;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiBancarioJApplicationTests {

	@Test
	void contextLoads() {
	}

}
