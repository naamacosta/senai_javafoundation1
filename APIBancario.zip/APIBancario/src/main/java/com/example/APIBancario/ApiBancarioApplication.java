package com.example.APIBancario;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiBancarioApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiBancarioApplication.class, args);
	}

}
